using Microsoft.EntityFrameworkCore;
using online_health_portal.Data;

var builder = WebApplication.CreateBuilder(args);

// --------------------
// Add Services
// --------------------

// Add MVC
builder.Services.AddControllersWithViews();

// Add Database
builder.Services.AddDbContext<MyContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);

// Required for Session
builder.Services.AddDistributedMemoryCache();

// Add HttpContext Accessor (if needed)
builder.Services.AddHttpContextAccessor();

// Add Session
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(10);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// --------------------
// Build App
// --------------------
var app = builder.Build();

// --------------------
// Configure Middleware
// --------------------

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Session must be before Authorization
app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=User}/{action=Index}/{id?}"
);

app.Run();
