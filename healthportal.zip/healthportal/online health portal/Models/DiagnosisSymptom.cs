﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class DiagnosisSymptom
{
    public int DiagnosisSymptomId { get; set; }

    public int DiagnosisId { get; set; }

    public string Symptom { get; set; } = null!;

    public virtual Aidiagnosis Diagnosis { get; set; } = null!;
}
