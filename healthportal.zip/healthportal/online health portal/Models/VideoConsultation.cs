﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class VideoConsultation
{
    public int VideoId { get; set; }

    public int AppointmentId { get; set; }

    public string? MeetingLink { get; set; }

    public DateTime? StartTime { get; set; }

    public DateTime? EndTime { get; set; }

    public virtual Appointment Appointment { get; set; } = null!;
}
