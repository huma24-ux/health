﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class RecordSharing
{
    public int ShareId { get; set; }

    public int RecordId { get; set; }

    public int DoctorId { get; set; }

    public bool? IsApproved { get; set; }

    public DateTime? SharedAt { get; set; }

    public virtual Doctor Doctor { get; set; } = null!;

    public virtual MedicalRecord Record { get; set; } = null!;
}
