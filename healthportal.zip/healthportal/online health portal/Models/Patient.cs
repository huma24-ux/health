﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class Patient
{
    public int PatientId { get; set; }

    public int UserId { get; set; }

    public DateOnly? DateOfBirth { get; set; }

    public string? Gender { get; set; }

    public string? BloodGroup { get; set; }

    public string? Address { get; set; }

    public string? ProfileImage { get; set; }

    public virtual ICollection<Aidiagnosis> Aidiagnoses { get; set; } = new List<Aidiagnosis>();

    public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();

    public virtual ICollection<DoctorReview> DoctorReviews { get; set; } = new List<DoctorReview>();

    public virtual ICollection<InsuranceDetail> InsuranceDetails { get; set; } = new List<InsuranceDetail>();

    public virtual ICollection<MedicalRecord> MedicalRecords { get; set; } = new List<MedicalRecord>();

    public virtual User User { get; set; } = null!;
}
