﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class DoctorLanguage
{
    public int DoctorLanguageId { get; set; }

    public int DoctorId { get; set; }

    public string Language { get; set; } = null!;

    public virtual Doctor Doctor { get; set; } = null!;
}
