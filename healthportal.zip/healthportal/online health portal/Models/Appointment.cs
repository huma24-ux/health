﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class Appointment
{
    public int AppointmentId { get; set; }

    public int DoctorId { get; set; }

    public int PatientId { get; set; }

    public DateTime AppointmentDate { get; set; }

    public string? ConsultationType { get; set; }

    public string? Status { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Doctor Doctor { get; set; } = null!;

    public virtual Invoice? Invoice { get; set; }

    public virtual Patient Patient { get; set; } = null!;

    public virtual Prescription? Prescription { get; set; }

    public virtual VideoConsultation? VideoConsultation { get; set; }
}
