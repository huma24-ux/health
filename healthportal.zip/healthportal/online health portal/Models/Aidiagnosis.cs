﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class Aidiagnosis
{
    public int DiagnosisId { get; set; }

    public int PatientId { get; set; }

    public string? SuggestedCondition { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual ICollection<DiagnosisSymptom> DiagnosisSymptoms { get; set; } = new List<DiagnosisSymptom>();

    public virtual Patient Patient { get; set; } = null!;
}
