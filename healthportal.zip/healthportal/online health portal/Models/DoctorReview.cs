﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class DoctorReview
{
    public int ReviewId { get; set; }

    public int DoctorId { get; set; }

    public int PatientId { get; set; }

    public int Rating { get; set; }

    public string? ReviewText { get; set; }

    public DateTime? ReviewDate { get; set; }

    public virtual Doctor Doctor { get; set; } = null!;

    public virtual Patient Patient { get; set; } = null!;
}
