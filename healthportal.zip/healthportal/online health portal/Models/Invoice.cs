﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class Invoice
{
    public int InvoiceId { get; set; }

    public int AppointmentId { get; set; }

    public decimal? Amount { get; set; }

    public bool? IsPaid { get; set; }

    public DateTime? GeneratedAt { get; set; }

    public virtual Appointment Appointment { get; set; } = null!;
}
