﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class MedicalRecord
{
    public int RecordId { get; set; }

    public int PatientId { get; set; }

    public string? Title { get; set; }

    public string? Description { get; set; }

    public string? FilePath { get; set; }

    public DateTime? UploadedAt { get; set; }

    public virtual Patient Patient { get; set; } = null!;

    public virtual ICollection<RecordSharing> RecordSharings { get; set; } = new List<RecordSharing>();
}
