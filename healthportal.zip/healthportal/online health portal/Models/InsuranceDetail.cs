﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class InsuranceDetail
{
    public int InsuranceId { get; set; }

    public int PatientId { get; set; }

    public string? CompanyName { get; set; }

    public string? PolicyNumber { get; set; }

    public string? CoverageDetails { get; set; }

    public virtual Patient Patient { get; set; } = null!;
}
