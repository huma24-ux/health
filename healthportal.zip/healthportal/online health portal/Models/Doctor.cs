﻿using System;
using System.Collections.Generic;

namespace online_health_portal.Models;

public partial class Doctor
{
    public int DoctorId { get; set; }

    public int UserId { get; set; }

    public string? Specialization { get; set; }

    public string? Qualification { get; set; }

    public int? ExperienceYears { get; set; }

    public string? Location { get; set; }

    public decimal? ConsultationFee { get; set; }

    public string? ProfileImage { get; set; }

    public bool? IsApproved { get; set; }

    public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();

    public virtual ICollection<DoctorLanguage> DoctorLanguages { get; set; } = new List<DoctorLanguage>();

    public virtual ICollection<DoctorReview> DoctorReviews { get; set; } = new List<DoctorReview>();

    public virtual ICollection<RecordSharing> RecordSharings { get; set; } = new List<RecordSharing>();

    public virtual User User { get; set; } = null!;
}
