using System.Diagnostics;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using online_health_portal.Data;
using online_health_portal.Models;

namespace online_health_portal.Controllers
{

    public class UserController : Controller
    {
        private readonly MyContext _context;

        public UserController(MyContext context)
        {
            _context = context;
        }

        // ================= DASHBOARD =================

        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetString("user_id");

            if (userId != null)
            {
                ViewBag.UserName = HttpContext.Session.GetString("user_name");
                return View();
            }

            return RedirectToAction("Login");
        }

        // ================= REGISTER =================

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                var existing = _context.Users
                    .FirstOrDefault(u => u.Email == user.Email);

                if (existing != null)
                {
                    ViewBag.error = "Email already exists!";
                    return View();
                }

                var hasher = new PasswordHasher<User>();
                user.PasswordHash = hasher.HashPassword(user, user.PasswordHash);

                user.Role = "Patient"; // default role
                user.CreatedAt = DateTime.Now;

                _context.Users.Add(user);
                _context.SaveChanges();

                return RedirectToAction("Login");
            }

            return View(user);
        }

        // ================= LOGIN =================

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var row = _context.Users
                .FirstOrDefault(u => u.Email == email);

            if (row != null)
            {
                var hasher = new PasswordHasher<User>();

                var result = hasher.VerifyHashedPassword(
                    row,
                    row.PasswordHash,
                    password
                );

                if (result == PasswordVerificationResult.Success)
                {
                    HttpContext.Session.SetString("user_id", row.UserId.ToString());
                    HttpContext.Session.SetString("role", row.Role);
                    HttpContext.Session.SetString("user_name", row.FullName);

                    // Role based redirect
                    if (row.Role == "Admin")
                        return RedirectToAction("Index", "Admin");

                    if (row.Role == "Doctor")
                        return RedirectToAction("Index", "Doctor");

                    if (row.Role == "Patient")
                        return RedirectToAction("Index", "Patient");

                    return RedirectToAction("Index");
                }
            }

            ViewBag.error = "Invalid Credentials";
            return View();
        }

        // ================= LOGOUT =================

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
