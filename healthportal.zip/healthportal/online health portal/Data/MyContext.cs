﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using online_health_portal.Models;

namespace online_health_portal.Data;

public partial class MyContext : DbContext
{
    public MyContext()
    {
    }

    public MyContext(DbContextOptions<MyContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }

    public virtual DbSet<Aidiagnosis> Aidiagnoses { get; set; }

    public virtual DbSet<Appointment> Appointments { get; set; }

    public virtual DbSet<DiagnosisSymptom> DiagnosisSymptoms { get; set; }

    public virtual DbSet<Doctor> Doctors { get; set; }

    public virtual DbSet<DoctorLanguage> DoctorLanguages { get; set; }

    public virtual DbSet<DoctorReview> DoctorReviews { get; set; }

    public virtual DbSet<InsuranceDetail> InsuranceDetails { get; set; }

    public virtual DbSet<Invoice> Invoices { get; set; }

    public virtual DbSet<MedicalRecord> MedicalRecords { get; set; }

    public virtual DbSet<Message> Messages { get; set; }

    public virtual DbSet<Notification> Notifications { get; set; }

    public virtual DbSet<Patient> Patients { get; set; }

    public virtual DbSet<Prescription> Prescriptions { get; set; }

    public virtual DbSet<PrescriptionMedicine> PrescriptionMedicines { get; set; }

    public virtual DbSet<RecordSharing> RecordSharings { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<VideoConsultation> VideoConsultations { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=DESKTOP-B18P4KG\\SQLEXPRESS02;Database=OnlineHealthPortalDB;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(e => e.AdminId).HasName("PK__Admins__719FE4886BB4F2BD");

            entity.HasIndex(e => e.UserId, "UQ__Admins__1788CC4DD2B0D9D1").IsUnique();

            entity.Property(e => e.AdminLevel).HasMaxLength(50);
            entity.Property(e => e.ProfileImage).HasMaxLength(255);

            entity.HasOne(d => d.User).WithOne(p => p.Admin)
                .HasForeignKey<Admin>(d => d.UserId)
                .HasConstraintName("FK__Admins__UserId__3D5E1FD2");
        });

        modelBuilder.Entity<Aidiagnosis>(entity =>
        {
            entity.HasKey(e => e.DiagnosisId).HasName("PK__AIDiagno__0C54CC73A3595268");

            entity.ToTable("AIDiagnosis");

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.SuggestedCondition).HasMaxLength(255);

            entity.HasOne(d => d.Patient).WithMany(p => p.Aidiagnoses)
                .HasForeignKey(d => d.PatientId)
                .HasConstraintName("FK__AIDiagnos__Patie__01142BA1");
        });

        modelBuilder.Entity<Appointment>(entity =>
        {
            entity.HasKey(e => e.AppointmentId).HasName("PK__Appointm__8ECDFCC2958E78F7");

            entity.Property(e => e.AppointmentDate).HasColumnType("datetime");
            entity.Property(e => e.ConsultationType).HasMaxLength(20);
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasDefaultValue("Pending");

            entity.HasOne(d => d.Doctor).WithMany(p => p.Appointments)
                .HasForeignKey(d => d.DoctorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Appointme__Docto__5535A963");

            entity.HasOne(d => d.Patient).WithMany(p => p.Appointments)
                .HasForeignKey(d => d.PatientId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Appointme__Patie__5629CD9C");
        });

        modelBuilder.Entity<DiagnosisSymptom>(entity =>
        {
            entity.HasKey(e => e.DiagnosisSymptomId).HasName("PK__Diagnosi__761FC2CFE3AA4E93");

            entity.Property(e => e.Symptom).HasMaxLength(255);

            entity.HasOne(d => d.Diagnosis).WithMany(p => p.DiagnosisSymptoms)
                .HasForeignKey(d => d.DiagnosisId)
                .HasConstraintName("FK__Diagnosis__Diagn__03F0984C");
        });

        modelBuilder.Entity<Doctor>(entity =>
        {
            entity.HasKey(e => e.DoctorId).HasName("PK__Doctors__2DC00EBF29C75BE4");

            entity.HasIndex(e => e.UserId, "UQ__Doctors__1788CC4DA3134876").IsUnique();

            entity.Property(e => e.ConsultationFee).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.IsApproved).HasDefaultValue(false);
            entity.Property(e => e.Location).HasMaxLength(150);
            entity.Property(e => e.ProfileImage).HasMaxLength(255);
            entity.Property(e => e.Qualification).HasMaxLength(200);
            entity.Property(e => e.Specialization).HasMaxLength(150);

            entity.HasOne(d => d.User).WithOne(p => p.Doctor)
                .HasForeignKey<Doctor>(d => d.UserId)
                .HasConstraintName("FK__Doctors__UserId__4222D4EF");
        });

        modelBuilder.Entity<DoctorLanguage>(entity =>
        {
            entity.HasKey(e => e.DoctorLanguageId).HasName("PK__DoctorLa__5053518F03BD0C5A");

            entity.HasIndex(e => new { e.DoctorId, e.Language }, "UQ_DoctorLanguage").IsUnique();

            entity.Property(e => e.Language).HasMaxLength(100);

            entity.HasOne(d => d.Doctor).WithMany(p => p.DoctorLanguages)
                .HasForeignKey(d => d.DoctorId)
                .HasConstraintName("FK__DoctorLan__Docto__45F365D3");
        });

        modelBuilder.Entity<DoctorReview>(entity =>
        {
            entity.HasKey(e => e.ReviewId).HasName("PK__DoctorRe__74BC79CE3E8D6C64");

            entity.Property(e => e.ReviewDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Doctor).WithMany(p => p.DoctorReviews)
                .HasForeignKey(d => d.DoctorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DoctorRev__Docto__4E88ABD4");

            entity.HasOne(d => d.Patient).WithMany(p => p.DoctorReviews)
                .HasForeignKey(d => d.PatientId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__DoctorRev__Patie__4F7CD00D");
        });

        modelBuilder.Entity<InsuranceDetail>(entity =>
        {
            entity.HasKey(e => e.InsuranceId).HasName("PK__Insuranc__74231A24C962EB94");

            entity.Property(e => e.CompanyName).HasMaxLength(150);
            entity.Property(e => e.CoverageDetails).HasMaxLength(255);
            entity.Property(e => e.PolicyNumber).HasMaxLength(100);

            entity.HasOne(d => d.Patient).WithMany(p => p.InsuranceDetails)
                .HasForeignKey(d => d.PatientId)
                .HasConstraintName("FK__Insurance__Patie__7D439ABD");
        });

        modelBuilder.Entity<Invoice>(entity =>
        {
            entity.HasKey(e => e.InvoiceId).HasName("PK__Invoices__D796AAB5FAA50463");

            entity.HasIndex(e => e.AppointmentId, "UQ__Invoices__8ECDFCC3C92CB393").IsUnique();

            entity.Property(e => e.Amount).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.GeneratedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsPaid).HasDefaultValue(false);

            entity.HasOne(d => d.Appointment).WithOne(p => p.Invoice)
                .HasForeignKey<Invoice>(d => d.AppointmentId)
                .HasConstraintName("FK__Invoices__Appoin__7A672E12");
        });

        modelBuilder.Entity<MedicalRecord>(entity =>
        {
            entity.HasKey(e => e.RecordId).HasName("PK__MedicalR__FBDF78E9B35F845F");

            entity.Property(e => e.FilePath).HasMaxLength(255);
            entity.Property(e => e.Title).HasMaxLength(150);
            entity.Property(e => e.UploadedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Patient).WithMany(p => p.MedicalRecords)
                .HasForeignKey(d => d.PatientId)
                .HasConstraintName("FK__MedicalRe__Patie__656C112C");
        });

        modelBuilder.Entity<Message>(entity =>
        {
            entity.HasKey(e => e.MessageId).HasName("PK__Messages__C87C0C9CEFA53A1D");

            entity.Property(e => e.SentAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.ReceiverUser).WithMany(p => p.MessageReceiverUsers)
                .HasForeignKey(d => d.ReceiverUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Messages__Receiv__6FE99F9F");

            entity.HasOne(d => d.SenderUser).WithMany(p => p.MessageSenderUsers)
                .HasForeignKey(d => d.SenderUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Messages__Sender__6EF57B66");
        });

        modelBuilder.Entity<Notification>(entity =>
        {
            entity.HasKey(e => e.NotificationId).HasName("PK__Notifica__20CF2E120AB1175A");

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsRead).HasDefaultValue(false);
            entity.Property(e => e.Title).HasMaxLength(255);

            entity.HasOne(d => d.User).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__Notificat__UserI__74AE54BC");
        });

        modelBuilder.Entity<Patient>(entity =>
        {
            entity.HasKey(e => e.PatientId).HasName("PK__Patients__970EC36653A5ED53");

            entity.HasIndex(e => e.UserId, "UQ__Patients__1788CC4D8CD4701D").IsUnique();

            entity.Property(e => e.Address).HasMaxLength(255);
            entity.Property(e => e.BloodGroup).HasMaxLength(10);
            entity.Property(e => e.Gender).HasMaxLength(20);
            entity.Property(e => e.ProfileImage).HasMaxLength(255);

            entity.HasOne(d => d.User).WithOne(p => p.Patient)
                .HasForeignKey<Patient>(d => d.UserId)
                .HasConstraintName("FK__Patients__UserId__49C3F6B7");
        });

        modelBuilder.Entity<Prescription>(entity =>
        {
            entity.HasKey(e => e.PrescriptionId).HasName("PK__Prescrip__4013083273AD9828");

            entity.HasIndex(e => e.AppointmentId, "UQ__Prescrip__8ECDFCC35F858F96").IsUnique();

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Appointment).WithOne(p => p.Prescription)
                .HasForeignKey<Prescription>(d => d.AppointmentId)
                .HasConstraintName("FK__Prescript__Appoi__5EBF139D");
        });

        modelBuilder.Entity<PrescriptionMedicine>(entity =>
        {
            entity.HasKey(e => e.PrescriptionMedicineId).HasName("PK__Prescrip__2C5AC23658E839A4");

            entity.Property(e => e.Dosage).HasMaxLength(100);
            entity.Property(e => e.MedicineName).HasMaxLength(255);

            entity.HasOne(d => d.Prescription).WithMany(p => p.PrescriptionMedicines)
                .HasForeignKey(d => d.PrescriptionId)
                .HasConstraintName("FK__Prescript__Presc__619B8048");
        });

        modelBuilder.Entity<RecordSharing>(entity =>
        {
            entity.HasKey(e => e.ShareId).HasName("PK__RecordSh__D32A3FEEE532D6DF");

            entity.ToTable("RecordSharing");

            entity.Property(e => e.IsApproved).HasDefaultValue(false);
            entity.Property(e => e.SharedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Doctor).WithMany(p => p.RecordSharings)
                .HasForeignKey(d => d.DoctorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__RecordSha__Docto__6B24EA82");

            entity.HasOne(d => d.Record).WithMany(p => p.RecordSharings)
                .HasForeignKey(d => d.RecordId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__RecordSha__Recor__6A30C649");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__1788CC4C88C78E54");

            entity.HasIndex(e => e.Email, "UQ__Users__A9D105349B63FBEC").IsUnique();

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(150);
            entity.Property(e => e.FullName).HasMaxLength(150);
            entity.Property(e => e.PasswordHash).HasMaxLength(255);
            entity.Property(e => e.Phone).HasMaxLength(20);
            entity.Property(e => e.Role).HasMaxLength(20);
        });

        modelBuilder.Entity<VideoConsultation>(entity =>
        {
            entity.HasKey(e => e.VideoId).HasName("PK__VideoCon__BAE5126A8304442D");

            entity.HasIndex(e => e.AppointmentId, "UQ__VideoCon__8ECDFCC3D4A07F71").IsUnique();

            entity.Property(e => e.EndTime).HasColumnType("datetime");
            entity.Property(e => e.MeetingLink).HasMaxLength(500);
            entity.Property(e => e.StartTime).HasColumnType("datetime");

            entity.HasOne(d => d.Appointment).WithOne(p => p.VideoConsultation)
                .HasForeignKey<VideoConsultation>(d => d.AppointmentId)
                .HasConstraintName("FK__VideoCons__Appoi__59FA5E80");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
